/* Écran de piste : reçoit le flux du serveur et affiche la scène choisie en régie.
   Écrit en JavaScript simple (ES5) pour les navigateurs de téléviseurs anciens. */
(function () {
  "use strict";
  var NOM = decodeURIComponent((location.pathname.split("/")[2] || "public"));
  var params = {};
  location.search.replace(/[?&]([^=&]+)=([^&]*)/g, function (_, k, v) { params[k] = decodeURIComponent(v); });
  var APERCU = params.apercu === "1";
  var SCENE_FORCEE = params.scene || null;
  var EDITEUR = params.editeur === "1";   // aperçu de l'éditeur de mise en page (page Administration)
  // aperçu du Centre de contrôle : la page parente reçoit un seul flux pour tous les écrans et nous passe nos événements
  var RELAIS = APERCU && params.relais === "1" && window.parent !== window;
  var opts = {};                          // réglages de cet écran (Administration)
  var mep = null;                         // mise en page personnalisée affichée

  var etat = { epreuve: {}, couple: {}, precedent: {}, suivant: {}, horloge: {}, classement: [], depart: [] };
  var scene = "public";
  var message = null, messageFin = 0;
  var $ = function (id) { return document.getElementById(id); };
  // plusieurs pistes sur le même écran : colonnes côte à côte (4 pistes : 2 x 2), texte réduit d'autant
  var MULTI = { multi: 1, multi_classement: 1 };
  var FACTEUR_MULTI = { 1: 1, 2: .66, 3: .5, 4: .6 };

  // ---------------------------------------------------------------- taille
  function taille() {
    // marge de sécurité (téléviseurs qui rognent les bords) et écran monté de côté
    var W = window.innerWidth, H = window.innerHeight, rot = +opts.rotation || 0, m = (+opts.marge || 0) / 100;
    var bw = rot === 90 || rot === 270 ? H : W, bh = rot === 90 || rot === 270 ? W : H;
    var mx = Math.round(bw * m), my = Math.round(bh * m), w = bw - 2 * mx, h = bh - 2 * my;
    var b = document.body.style, tx = mx, ty = my;
    if (rot === 90) { tx = W - my; ty = mx; } else if (rot === 180) { tx = W - mx; ty = H - my; } else if (rot === 270) { tx = my; ty = H - mx; }
    if (rot || m) {
      var tr = "translate(" + tx + "px," + ty + "px) rotate(" + rot + "deg)";
      b.position = "absolute"; b.left = "0"; b.top = "0"; b.width = w + "px"; b.height = h + "px";
      b.webkitTransformOrigin = b.transformOrigin = "0 0"; b.webkitTransform = b.transform = tr;
    } else {
      b.position = b.left = b.top = b.width = b.height = b.webkitTransform = b.transform = "";
    }
    var sMep = String(SCENE_FORCEE || scene).indexOf("mep:") === 0 || EDITEUR;
    var portrait = h > w * 1.1 && scene !== "incrustation" && !sMep;
    var u = portrait ? w / 50 : Math.min(w, h * 16 / 9) / 100;
    if (!sMep) u *= (+opts.texte || 100) / 100;
    if (MULTI[SCENE_FORCEE || scene] && !portrait) u *= FACTEUR_MULTI[Math.min(4, (etat.pistes || []).length)] || 1;
    document.documentElement.style.fontSize = u + "px";
    document.documentElement.className = portrait ? "portrait" : "";
  }
  window.onresize = taille;

  // ---------------------------------------------------------------- outils
  function esc(v) {
    if (v === null || v === undefined) return "";
    return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function vide(o) { for (var k in o) if (o.hasOwnProperty(k)) return false; return true; }
  function classes(liste) {
    var out = [];
    for (var i = 0; i < (liste || []).length; i++) {
      var r = liste[i];
      if (r.points !== null || r.temps !== null || (r.rang && r.rang !== "-")) out.push(r);
    }
    return out;
  }
  // 1er, 2e… ou 1st, 2nd… selon la langue de l'écran
  function suf(n) {
    if (typeof I18N === "undefined" || I18N.langue() !== "en") return n === 1 ? "er" : "e";
    var d = n % 100;
    return d > 10 && d < 14 ? "th" : ["th", "st", "nd", "rd"][n % 10] || "th";
  }
  function rangTexte(r, suffixe) {
    if (!r || r === "-") return "";
    if (/el/i.test(r)) return "Élim.";
    if (/ab/i.test(r)) return "Ab.";
    var n = parseInt(r, 10);
    if (isNaN(n)) return esc(r);
    return suffixe ? n + suf(n) : String(n);
  }
  function tempsTexte(t) {
    if (t === null || t === undefined || t === "") return "";
    if (typeof t === "number") return t.toFixed(2);
    if (t === "El") return "Élim.";
    if (t === "Ab") return "Abandon";
    return esc(t);
  }

  // ---------------------------------------------------------------- chrono
  function deux(n) { return (n < 10 ? "0" : "") + n; }
  function heureDuJour() {
    var d = new Date();
    return deux(d.getHours()) + ":" + deux(d.getMinutes()) + ":" + deux(d.getSeconds());
  }
  var INTER_FIGE_MS = 4000;     // temps intermédiaire figé à l'écran, puis le chrono repart
  function interFige(h) {
    var l = h.intermediaires || [];
    return h.state === "en_course" && l.length && h.interRecu && Date.now() - h.interRecu < INTER_FIGE_MS ? l.length : 0;
  }
  // deux phases : à la fin de la 1re phase, son temps reste figé quelques secondes, puis le chrono de la 2e repart de 0
  var PHASE1_FIGE_MS = 3000;
  function phase1Fige(h) { return h.state === "en_course" && h.phase_1 != null && h.phase1Recu && Date.now() - h.phase1Recu < PHASE1_FIGE_MS; }
  function poserPhase1(h, avant) {
    h.phase1Recu = h.phase_1 == null ? 0 : avant && avant.phase_1 === h.phase_1 ? avant.phase1Recu : Date.now();
    return h;
  }
  function chronoTexte() {
    var h = etat.horloge || {};
    var dt = (Date.now() - (h.recu || Date.now())) / 1000, fi = interFige(h);
    if (phase1Fige(h)) return tempsTexte(h.phase_1);
    if (fi) return tempsTexte(h.intermediaires[fi - 1]);
    if (h.state === "en_course" && typeof h.time === "number") {
      var t = h.time + Math.min(1.2, dt);
      return (Math.floor(t * 10) / 10).toFixed(1);
    }
    if (h.state === "compte_a_rebours" && typeof h.time === "number") {
      return "-" + Math.max(0, Math.ceil(h.time - dt));
    }
    if (h.state === "termine") return tempsTexte(h.time);
    if (h.state === "attente") return "0.0";
    return "";
  }
  function fautesTexte() {
    var h = etat.horloge || {};
    if (interFige(h)) return "Int. <b>" + interFige(h) + "</b>";
    if (phase1Fige(h)) return "1<sup>re</sup> phase";
    if (h.phase_1 != null && h.state === "en_course") return "2<sup>e</sup> phase · 1<sup>re</sup> <b>" + tempsTexte(h.phase_1) + "</b>";
    if (h.progressif) return '<b class="pts">' + esc(h.progressif.points) + "</b> pts";
    if (h.faults === null || h.faults === undefined) return "";
    return "Pén. <b>" + esc(h.faults) + "</b>";
  }
  // difficultés progressives : une case par obstacle (vert franchi, rouge tombé), le joker en pointillé
  function cleProgressif(h) { var p = (h || {}).progressif, o = (h || {}).obstacles; return (p ? p.sauts + "/" + p.joker + "/" + p.nb + "/" + p.points : "") + (o ? "|" + o.l.join(",") + JSON.stringify(o.f) : ""); }
  // CSO, fautes par obstacle (si le jury les note) : le parcours colorié, rouge barre, orange refus
  function barreObstacles() {
    var o = (etat.horloge || {}).obstacles;
    if (!o || !o.l || !o.l.length || !(etat.couple || {}).dossard) return "";
    var f = o.f || {};
    return '<div class="obstacles-cso">' + o.l.map(function (n) {
      var c = f[n] || "", b = c.indexOf("b") >= 0, r = /[rc]/.test(c);
      return '<span class="' + (b ? "ob-b" : r ? "ob-r" : "") + '">' + esc(n) + "</span>";
    }).join("") + "</div>";
  }
  function barreProgressif() {
    var p = (etat.horloge || {}).progressif;
    if (!p || !(etat.couple || {}).dossard) return "";
    var s = String(p.sauts || ""), nb = Math.min(40, +p.nb || 0), html = "";
    for (var n = 1; n <= nb; n++) {
      var c = s.charAt(n - 1), jk = Math.abs(+p.joker) === n, v = n * (+p.joker === n ? 2 : +p.joker === -n ? 4 : 1);
      html += '<div class="pg' + (c === "o" ? " ok" : c === "x" ? " ko" : n === s.length + 1 ? " cur" : "") + (jk ? " jk" : "") + '"><b>' +
        (c === "o" ? "+" + v : c === "x" ? "\u2212" + v : v) + "</b><span>" + (jk ? (+p.joker < 0 ? "SUPER JOKER" : "JOKER") : n) + "</span></div>";
    }
    return '<div class="progressif">' + html + "</div>";
  }
  function tic() {
    if (MULTI[vu.sceneReelle]) ticPistes();
    else {
      var el = document.querySelectorAll(".chrono .t, .chrono-mep .t");
      var txt = chronoTexte();
      for (var i = 0; i < el.length; i++) if (el[i].innerHTML !== txt) el[i].innerHTML = txt;
    }
    ticCloche();
    var hj = document.querySelector(".tableau .hj");
    if (hj) { var th = heureDuJour(); if (hj.innerHTML !== th) hj.innerHTML = th; }
    if (message && Date.now() > messageFin) { message = null; dessinerMessage(); }
    ticDecompte();
    ticCross();
  }
  setInterval(tic, 100);

  // ---------------------------------------------------------------- animations
  // Une animation ne se joue qu'au changement réel (nouveau couple, nouveau résultat…),
  // pas à chaque rafraîchissement de l'écran.
  var vu = { couple: null, resultat: null, precedent: null, scene: null, ligne: null };
  var anim = { couple: false, resultat: false, precedent: false, flash: null };
  function preparerAnimations(s) {
    var c = etat.couple || {}, res = c.resultat || {}, p = etat.precedent || {};
    var cle = c.dossard ? (etat.epreuve || {}).epreuve + "/" + (c.manche || 1) + "/" + c.dossard : "";   // barrage : nouvelle entrée
    var cleRes = cle && (res.rang || res.temps !== undefined) ? cle + "/" + res.rang + "/" + res.temps : "";
    var cleP = p.dossard ? p.dossard + "/" + p.rang : "";
    anim.couple = cle !== vu.couple && !!cle;
    anim.resultat = cleRes !== vu.resultat && !!cleRes;
    anim.precedent = cleP !== vu.precedent && !!cleP && vu.precedent !== null;
    // le couple entre au classement ou y change de place : sa ligne s'illumine
    var ligne = null, cl = etat.classement || [];
    for (var i = 0; i < cl.length; i++) if (cl[i].dossard === c.dossard) ligne = cl[i];
    var cleL = ligne ? cle + "/" + ligne.rang + "/" + ligne.points + "/" + ligne.temps : "";
    anim.flash = cleL && vu.ligne !== null && cleL !== vu.ligne ? c.dossard : null;
    vu.couple = cle; vu.resultat = cleRes; vu.precedent = cleP; vu.ligne = cleL;
  }

  // ---------------------------------------------------------------- blocs
  var PARTICULES = { de: 1, des: 1, du: 1, la: 1, le: 1, les: 1, et: 1, van: 1, von: 1, der: 1, den: 1, z: 0 };
  function joliNom(t) {
    if (!t || t !== String(t).toUpperCase()) return t || "";
    return String(t).toLowerCase().replace(/(^|[\s\-'’])([^\s\-'’]+)/g, function (_, sep, mot, pos) {
      if (pos > 0 && PARTICULES[mot] === 1) return sep + mot;
      if (/^(d|l)$/.test(mot) && /['’]/.test(t.charAt(pos + sep.length + 1))) return sep + mot;
      return sep + mot.charAt(0).toUpperCase() + mot.slice(1);
    });
  }
  // nation : code à 3 lettres, avec le petit drapeau si l'écran l'affiche (option « Drapeaux des nations »)
  function drapeauxActifs() { return opts.drapeaux !== false && typeof DRAPEAUX !== "undefined"; }
  function imgDrapeau(n) { var u = drapeauxActifs() ? DRAPEAUX.url(n) : ""; return u ? '<img class="drap" src="' + u + '" alt="">' : ""; }
  function natBadge(n) {
    if (!n) return "";
    var i = imgDrapeau(n);
    return '<span class="nat' + (i ? " avec-drap" : "") + '">' + i + esc(n) + "</span>";
  }
  function natCellule(n) { return n ? imgDrapeau(n) + esc(n) : ""; }
  function entete() {
    var e = etat.epreuve || {};
    if (!e.nom) return "";
    var sur = [];
    if (e.concours) sur.push(e.concours);
    if (etat.nb_carrieres > 1 && etat.carriere) sur.push(etat.carriere);
    sur.push("Épreuve " + (e.epreuve || ""));
    var puces = "";
    if (e.temps_accorde) puces += /complet · cross/i.test(e.bareme || "") ? '<span class="puce">Optimum <b>' + mmss(+e.temps_accorde) + "</b></span>"
      : '<span class="puce">TA <b>' + esc(e.temps_accorde) + " s</b></span>";
    if (e.partis !== null && e.partis !== undefined && e.partants) puces += '<span class="puce"><b>' + esc(e.partis) + "</b> / " + esc(e.partants) + " partis</span>";
    if (e.sans_faute) puces += '<span class="puce"><b>' + esc(e.sans_faute) + "</b> sans faute</span>";
    var pct = e.partants ? Math.max(0, Math.min(100, Math.round(100 * (+e.partis || 0) / +e.partants))) : -1;
    if (e.fin_estimee && pct >= 0 && pct < 100) puces += '<span class="puce">Fin <b>' + esc(e.fin_estimee) + "</b></span>";
    return '<div class="entete"><div class="titre"><div class="sur">' + esc(sur.join("  ·  ")) + '</div><div class="nom">' + esc(e.nom) +
      '</div></div><div class="infos">' + puces + "</div>" +
      (pct >= 0 ? '<div class="entete-avance"><i style="width:' + pct + '%"></i></div>' : "") + "</div>";
  }
  function etatChrono() {
    var s = (etat.horloge || {}).state;
    return s === "compte_a_rebours" ? "Compte à rebours" : s === "en_course" ? "En course" : s === "termine" ? "Arrivée" : "";
  }
  function carteCouple(cls) {
    var c = etat.couple || {};
    if (!c.dossard) return "";
    var h = etat.horloge || {}, res = c.resultat || {};
    var rt = rangTexte(res.rang, true), ko = /el|ab|re/i.test(res.rang || "");
    var rang = rt ? '<span class="rang' + (ko ? " ko" : "") + '">' + rt + "</span>" : "";
    return '<div class="' + (cls || "piste") + (anim.couple ? " entre" : "") + (anim.resultat ? "" : " calme") + " etat-" + esc(h.state) + '">' +
      '<div class="dossard">' + esc(c.dossard) + "</div>" +
      '<div class="qui"><div class="cav">' + esc(c.cavalier) + natBadge(c.nation) +
      '</div><div class="chv">' + esc(joliNom(c.cheval)) + "</div></div>" +
      (hunterActif() ? '<div class="chrono"><div class="e">Note</div><div class="tn">' + noteHunter(res.penalites) + '</div><div class="f">' + rang + "</div></div></div>"
        : '<div class="chrono"><div class="e">' + etatChrono() + '</div><div class="t">' + chronoTexte() + '</div><div class="f">' + rang + '<span class="fp">' + fautesTexte() + "</span></div></div></div>") +
      barreProgressif() + barreObstacles();
  }
  // hunter : pas de chrono, la note des juges à la place
  function hunterActif() { return /^Hunter/.test((etat.epreuve || {}).bareme || ""); }
  function noteHunter(p) { return /pts$/.test(p || "") ? esc(String(p).replace(" pts", "").replace(".", ",")) + "<i> pts</i>" : "–"; }
  function tableClassement(lignes, max) {
    if (+opts.lignes > 0) max = Math.min(max, +opts.lignes);
    var rows = classes(lignes).slice(0, max), dos = (etat.couple || {}).dossard, html = "";
    if (!rows.length) return '<div class="vide">Le classement s\'affichera après le premier parcours.</div>';
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i], n = parseInt(r.rang, 10), elim = /el|ab|re/i.test(r.points || r.rang || "");
      var cl = (r.dossard === dos ? "moi" : "") + (r.dossard === anim.flash ? " flash" : "") + (n <= 3 ? " podium r" + n : "");
      html += '<tr class="' + cl + '"><td class="r"><span>' + (isNaN(n) ? "–" : n) + '</span></td><td class="n' + (imgDrapeau(r.nation) ? " nd" : "") + '">' + natCellule(r.nation) + '</td><td class="d">' + esc(r.dossard) +
        '</td><td class="nm"><b>' + esc(r.cavalier) + (r.reserve ? ' <i class="sr">sous réserve</i>' : "") + "</b><span>" + esc(joliNom(r.cheval)) + "</span></td>" +
        (elim ? '<td class="el" colspan="2">' + rangTexte(r.points || r.rang) + "</td>"
              : /%|pts$/.test(r.points || "") ? '<td class="p pct" colspan="2">' + esc(String(r.points).replace(".", ",")) + "</td>"     // dressage (%), hunter (note) : deux colonnes
              : '<td class="p' + (r.points === "0" || r.points === 0 ? " z" : "") + '">' + esc(r.points) + '</td><td class="tp">' + esc(r.temps) + "</td>") + "</tr>";
    }
    return '<table class="liste">' + html + "</table>";
  }
  function blocCouple(titre, c, avecResultat) {
    if (!c || !c.dossard) return "";
    var res = "";
    if (avecResultat && (c.temps !== undefined || c.rang)) {
      var ko = /el|ab|re/i.test(String(c.rang || c.temps || "")), rt = rangTexte(c.rang, true);
      res = '<div class="res">' + (ko ? '<span class="rg ko">' + rt + "</span>"
        : '<div class="tp">' + tempsTexte(c.temps) + (rt ? '<span class="rg">' + rt + "</span>" : "") + "</div>" +
          (c.penalites !== null && c.penalites !== undefined && c.penalites !== "" ? '<div class="pp">' + esc(String(c.penalites).replace(/^(\d+)\.(\d+ (%|pts))$/, "$1,$2")) + (/%|pts$/.test(c.penalites) ? "" : " pt" + (c.penalites > 1 ? "s" : "")) + "</div>" : "")) + "</div>";
    }
    return "<h2>" + titre + '</h2><div class="bloc' + (avecResultat && anim.precedent ? " entre" : "") + '"><div class="db">' + esc(c.dossard) +
      '</div><div class="qui"><div class="ligne1">' + esc(c.cavalier) + '</div><div class="ligne2">' + esc(joliNom(c.cheval)) + "</div></div>" + res + "</div>";
  }
  // ---------------------------------------------------------------- cross du concours complet
  // Plusieurs chevaux sur le cross : une barre d'avancement chacun. Le serveur donne l'heure de départ et les heures
  // de passage aux points de contrôle ; l'écran fait avancer le cheval entre deux points à son allure (au temps
  // optimum avant le premier point), sans passer un point où il n'est pas encore signalé.
  var crossDecalage = 0;
  function poserCross(c) { etat.cross = c && c.couples && c.couples.length ? c : null; if (c && c.heure_ms) crossDecalage = c.heure_ms - Date.now(); }
  function crossActif() { return !!(etat.cross && etat.cross.couples && etat.cross.couples.length); }
  function avanceCross(cr, c) {
    if (c.etat === "arrive") return { f: 1, t: c.temps != null ? c.temps : c.ecoule };
    if (c.etat === "arrete") return { f: c.fraction || 0, t: c.ecoule || 0 };
    var t = Math.max(0, (Date.now() + crossDecalage - c.depart_ms) / 1000), f0 = 0, t0 = 0, pts = cr.points || [], opt = cr.temps_optimum;
    for (var i = 0; i < (c.passages || []).length; i++) { var p = c.passages[i], q = pts[p.point]; if (q && q.fraction >= f0) { f0 = q.fraction; t0 = p.temps; } }
    if (c.repere && c.repere.fraction > f0) { f0 = c.repere.fraction; t0 = c.repere.temps; }   // dernier obstacle noté par un commissaire
    var allure = t0 > 0 && f0 > 0 ? f0 / t0 : (opt ? 1 / opt : 0), suiv = 1;
    for (var j = 0; j < pts.length; j++) if (pts[j].fraction > f0 + 1e-9 && pts[j].fraction < suiv) suiv = pts[j].fraction;
    return { f: Math.max(f0, Math.min(f0 + Math.max(0, t - t0) * allure, suiv - 0.005, 0.995)), t: t };
  }
  function mmss(s) { s = Math.max(0, s || 0); var m = Math.floor(s / 60), r = Math.floor(s % 60); return m + ":" + (r < 10 ? "0" : "") + r; }
  function ecartCross(e) {
    if (e === null || e === undefined) return "";
    var r = Math.round(e);
    return '<span class="' + (r > 0 ? "retard" : "avance") + '">' + (r > 0 ? "+" : r < 0 ? "−" : "±") + Math.abs(r) + " s</span>";
  }
  function blocCross(max) {
    var cr = etat.cross, pts = cr.points || [], html = "", liste = cr.couples.slice(0, max);
    var enPiste = 0;
    for (var k = 0; k < cr.couples.length; k++) if (cr.couples[k].etat === "en_course") enPiste++;
    for (var i = 0; i < liste.length; i++) {
      var c = liste[i], faits = {}, der = (c.passages || []).slice(-1)[0], q = der && pts[der.point], r = c.resultat, a = avanceCross(cr, c);
      for (var j = 0; j < (c.passages || []).length; j++) faits[c.passages[j].point] = 1;
      var info = c.etat === "arrive" ? (r && r.etat === "couru" ? esc(r.points) + " pt" + (r.points > 1 ? "s" : "") : r && r.motif ? esc(r.motif) : "Arrivée " + ecartCross(c.ecart))
        : c.etat === "arrete" ? esc(c.arret || "Arrêté")
        : q ? esc(q.obstacle ? "Obst. " + q.obstacle : q.nom) + " " + ecartCross(der.ecart) : "Parti";
      if (c.refus && c.refus.length) info += ' <span class="retard">· refus ' + esc(c.refus.join(", ")) + "</span>";
      var pc = (a.f * 100).toFixed(2) + "%", rail = "";
      for (var x = 0; x < pts.length; x++) rail += '<i class="cp' + (faits[x] ? " passe" : "") + '" style="left:' + (pts[x].fraction * 100).toFixed(2) + '%"><span>' + esc(pts[x].obstacle || pts[x].nom) + "</span></i>";
      html += '<div class="cross-l ' + esc(c.etat) + '" data-cross="' + i + '"><div class="db">' + esc(c.dossard) + '</div><div class="qui"><div class="ligne1">' + esc(c.cavalier) +
        natBadge(c.nation) + '</div><div class="ligne2">' + esc(joliNom(c.cheval)) + "</div></div>" +
        '<div class="rail-c"><div class="rail"><b style="width:' + pc + '"></b>' + rail + '<em style="left:' + pc + '"></em></div></div>' +
        '<div class="res"><div class="tp">' + mmss(a.t) + '</div><div class="pp">' + info + "</div></div></div>";
    }
    return '<div class="cross-direct"><h2>Cross en direct <span class="doux">· ' + enPiste + " en piste" + (cr.temps_optimum ? " · temps optimum " + mmss(cr.temps_optimum) : "") + "</span></h2>" + html + "</div>";
  }
  function ticCross() {
    if (!crossActif()) return;
    var l = document.querySelectorAll(".cross-l");
    for (var i = 0; i < l.length; i++) {
      var c = etat.cross.couples[+l[i].getAttribute("data-cross")];
      if (!c) continue;
      var a = avanceCross(etat.cross, c), pc = (a.f * 100).toFixed(2) + "%", rail = l[i].querySelector(".rail"), t = l[i].querySelector(".tp"), txt = mmss(a.t);
      rail.firstChild.style.width = pc; rail.lastChild.style.left = pc;
      if (t.innerHTML !== txt) t.innerHTML = txt;
    }
  }

  // ---------------------------------------------------------------- dressage : les % des juges au fil des notes
  function dressageActif() { return !!(etat.dressage && etat.dressage.couple); }
  function pct(x) { return x === null || x === undefined ? "–" : Number(x).toFixed(3).replace(".", ","); }
  // cloche du juge en C : « Entrée dans 31 s » jusqu'à l'entrée du couple (heure du serveur pour caler le décompte)
  var ecartDressage = 0;
  function recevoirDressage(d) {
    etat.dressage = d || null;
    if (d && d.heure_ms) ecartDressage = d.heure_ms - Date.now();
  }
  function texteCloche(d) {
    if (!d || !d.cloche_ms) return "";
    if (d.entree_s !== undefined && d.entree_s !== null) return "Entré après " + String(Math.round(d.entree_s)) + " s";
    var reste = Math.ceil((d.delai_s || 45) - (Date.now() + ecartDressage - d.cloche_ms) / 1000);
    return reste >= 0 ? "Cloche · entrée dans " + reste + " s" : "Cloche · " + (-reste) + " s de retard";
  }
  function ticCloche() {
    var el = document.querySelectorAll(".cloche-dr"); if (!el.length) return;
    var txt = texteCloche(etat.dressage);
    for (var i = 0; i < el.length; i++) if (el[i].textContent !== txt) el[i].textContent = txt;
  }
  function blocDressage() {
    var d = etat.dressage, c = d.couple, j = "", fini = d.etat === "couru", elim = d.etat === "elimine";
    for (var i = 0; i < d.juges.length; i++) {
      var x = d.juges[i];
      j += '<div class="juge' + (x.valide ? " ok" : "") + '"><small>' + esc(x.juge) + "</small><b>" + pct(x.pourcentage) + (x.pourcentage !== null && x.pourcentage !== undefined ? "<i>%</i>" : "") +
        "</b><span>" + (x.valide ? "validé" : x.notes ? x.notes + " / " + d.nb_notes : "") + "</span></div>";
    }
    var res = elim ? '<div class="moy elim">' + esc(d.motif || "Éliminé") + "</div>"
      : '<div class="moy' + (fini ? " fini" : "") + '"><small>' + (fini ? (d.rang ? "Classé " + esc(d.rang) + suf(+d.rang) : "Résultat") : "Moyenne provisoire") + "</small><b>" + pct(d.pourcentage) + "<i>%</i></b>" +
        (d.erreurs ? "<span>" + esc(d.erreurs) + " erreur" + (d.erreurs > 1 ? "s" : "") + " de tracé</span>" : "") + "</div>";
    return '<div class="dressage-direct"><h2>En piste' + (d.reprise ? ' <span class="doux">· ' + esc(d.reprise) + "</span>" : "") +
      (d.cloche_ms ? ' <span class="doux cloche-dr">' + esc(texteCloche(d)) + "</span>" : "") + '</h2><div class="bloc"><div class="db">' + esc(c.dossard) +
      '</div><div class="qui"><div class="ligne1">' + esc(c.cavalier) + natBadge(c.nation) + '</div><div class="ligne2">' + esc(joliNom(c.cheval)) +
      '</div></div>' + res + '</div><div class="juges">' + j + "</div></div>";
  }

  function lignesPossibles(hauteurRem, ligneRem) {
    var h = window.innerHeight / parseFloat(document.documentElement.style.fontSize || 16);
    return Math.max(3, Math.floor((h - hauteurRem) / ligneRem));
  }

  // derniers résultats du cavalier et du cheval en piste (historique gardé par le serveur)
  var histo = {}, histoDemande = {};
  // infos masquées de la fiche speaker (réglées depuis la page Speaker, gardées par le serveur)
  // ce que le fichier d'engagés dit du couple : demandé une fois par couple, par l'écran speaker seulement
  // (réservé aux postes qui ont le code : sinon, la fiche reste celle du chrono)
  var fiches = {}, fichesDem = {};
  function ficheFichier(c) {
    if (!c || (!c.cavalier && !c.cheval)) return null;
    var k = [c.licence || c.cavalier, c.sire || c.cheval].join("|");
    if (fiches[k] || fichesDem[k]) return fiches[k] || null;
    fichesDem[k] = true;
    var x = new XMLHttpRequest(), q = ["licence", "sire", "cavalier", "cheval"].map(function (n) { return n + "=" + encodeURIComponent(c[n] || ""); }).join("&");
    x.open("GET", "/api/fiche_couple?" + q);
    x.onload = function () { if (x.status === 200) { try { fiches[k] = JSON.parse(x.responseText); dessiner(); } catch (e) { } } };
    x.send();
    return null;
  }
  function voirFiche(k) { var l = etat.ficheCaches || ["tetiere"]; for (var i = 0; i < l.length; i++) if (l[i] === k) return false; return true; }
  function historiqueCouple(c) {
    var vc = voirFiche("histo_cavalier"), vh = voirFiche("histo_cheval");
    if (!c || !c.dossard || (!vc && !vh)) return "";
    var k = [c.licence || c.cavalier, c.sire || c.cheval, c.epreuve, c.dossard, c.manche || 1].join("|"), d = histo[k];
    if (!d) {
      if (!histoDemande[k]) {
        histoDemande[k] = true;
        var x = new XMLHttpRequest(), q = ["licence", "sire", "cavalier", "cheval", "epreuve", "dossard", "manche"].map(function (n) { return n + "=" + encodeURIComponent(c[n] || ""); }).join("&");
        x.open("GET", "/api/historique?" + q + "&concours=" + encodeURIComponent(c.concours || (etat.epreuve || {}).concours || ""));
        x.onload = function () { try { histo[k] = JSON.parse(x.responseText); dessiner(); } catch (e) { } };
        x.onerror = function () { histoDemande[k] = false; };
        x.send();
      }
      return "";
    }
    // une seule liste, pour tenir sur l'écran : les parcours du cavalier (avec le cheval quand ce n'est pas le même),
    // complétés par ceux du cheval avec un autre cavalier
    var meme = function (a, b) { return String(a || "").toLowerCase() === String(b || "").toLowerCase(); };
    var l = vc ? (d.cavalier || []).slice(0, 3) : [], autres = (vh ? d.cheval || [] : []).filter(function (r) { return !meme(r.cavalier, c.cavalier); });
    l = l.concat(autres.slice(0, Math.max(1, 3 - l.length))).slice(0, 4);
    var h = "";
    for (var i = 0; i < l.length; i++) {
      var r = l[i], ko = /el|ab|re/i.test(String(r.rang || "") + String(r.temps || "")), rt = rangTexte(r.rang, true);
      var res = ko ? (rangTexte(r.rang) || tempsTexte(r.temps)) : (rt && /\d/.test(rt) ? rt + (r.partants ? "/" + r.partants : "") + " · " : "") +
        (+r.penalites === 0 ? "0 pt" : (r.penalites != null ? r.penalites + " pts" : "")) + (r.temps != null ? " · " + tempsTexte(r.temps) : "");
      var avec = !meme(r.cavalier, c.cavalier) ? (r.cavalier ? " · " + esc(r.cavalier) + " avec le cheval" : " · autre cavalier") : !meme(r.cheval, c.cheval) ? " · avec " + esc(joliNom(r.cheval)) : "";
      h += '<div class="hl"><span class="ep">' + esc(r.epreuve_nom || "Épreuve " + r.epreuve) + "<i>" + esc(r.concours || "") + avec + "</i></span><b>" + esc(res) + "</b></div>";
    }
    if (h) h = "<h2>Derniers résultats</h2>" + h;
    return h ? '<div class="histo">' + h + "</div>" : "";
  }

  // ---------------------------------------------------------------- scènes
  var SCENES = {
    public: function () {
      if (vide(etat.epreuve) || !etat.epreuve.nom) return SCENES.attente();
      var n = portrait() ? 10 : lignesPossibles(30, 3.35);
      if (crossActif()) {
        var nc = Math.min(etat.cross.couples.length, portrait() ? 6 : 4);
        return entete() + blocCross(nc) + '<div class="colonnes"><div style="-webkit-flex:1.7;flex:1.7"><h2>Classement</h2>' +
          tableClassement(etat.classement, portrait() ? 8 : Math.max(3, lignesPossibles(30 + nc * 6.6, 3.35))) + "</div><div>" + blocCouple("Précédent", etat.precedent, true) + "</div></div>";
      }
      return entete() + (dressageActif() ? blocDressage() : carteCouple()) + '<div class="colonnes"><div style="-webkit-flex:1.7;flex:1.7"><h2>Classement</h2>' +
        tableClassement(etat.classement, dressageActif() ? Math.max(3, n - 3) : n) + "</div><div>" + blocCouple("Précédent", etat.precedent, true) +
        blocCouple("Suivant", etat.suivant) + "</div></div>";
    },
    speaker: function () {
      var c0 = etat.couple || {}, e = etat.epreuve || {}, fiche = "", ff = ficheFichier(c0) || {}, c = {}, k;
      for (k in (ff.champs || {})) c[k] = ff.champs[k];
      for (k in c0) if (c0[k] !== null && c0[k] !== undefined && c0[k] !== "") c[k] = c0[k];
      var champs = [["Ordre", c.ordre, 0, "ordre"], ["Tétière", c.tetiere, 0, "tetiere"], ["Nation", c.nation, 0, "nation"], ["Club", c.club, 0, "club"],
        ["Licence", c.licence, 0, "licence"], ["Race", c.race, 0, "race"], ["Âge du cheval", c.age_cheval ? c.age_cheval + " ans" : null, 0, "age"],
        ["SIRE", c.sire, 0, "sire"], ["Père", c.pere, 0, "pere"], ["Mère", c.mere, 0, "mere"], ["Père de mère", c.pere_de_mere, 0, "pere_de_mere"],
        ["Sexe", c.sexe, 0, "sexe"], ["Robe", c.robe, 0, "robe"], ["Taille", c.taille ? c.taille + " cm" : null, 0, "taille"],
        ["Né en", c.naissance_cheval, 0, "naissance_cheval"], ["Pays de naissance", c.pays_naissance, 0, "pays_naissance"],
        ["Gains", c.gains ? Math.round(c.gains) + " €" : null, 0, "gains"], ["Région", c.region, 0, "region"],
        ["Département", c.departement, 0, "departement"], ["Entraîneur", c.entraineur, 0, "entraineur"], ["Heure", c.heure, 0, "heure"]];
      for (var j = champs.length - 1; j >= 0; j--) if (!voirFiche(champs[j][3])) champs.splice(j, 1);
      // colonnes du fichier d'engagés cochées sur la page Speaker (propriétaire, éleveur…)
      var cols = etat.ficheColonnes || [], src = [ff.cavalier || {}, ff.cheval || {}];
      for (var s = 0; s < src.length; s++) for (k in src[s]) if (cols.indexOf(k) >= 0) champs.push([k, src[s][k]]);
      if (c.masque) champs.unshift(["Cavalier", "Nom masqué à sa demande (RGPD) : ne pas l'annoncer", true]);
      for (var i = 0; i < champs.length; i++) if (champs[i][1]) fiche += '<div' + (champs[i][2] ? ' class="large"' : "") + "><small>" + champs[i][0] + "</small><span>" + esc(champs[i][1]) + "</span></div>";
      var st = function (t, v) { return v !== null && v !== undefined && v !== "" ? "<div><small>" + t + "</small><b>" + esc(v) + "</b></div>" : ""; };
      var stats = !voirFiche("stats") ? "" : '<div class="stats">' + st("Partis", e.partis !== null && e.partis !== undefined ? e.partis + " / " + e.partants : null) +
        st("Sans faute", e.sans_faute) + st("Restants", e.restants) + st("Fin estimée", e.fin_estimee) +
        (voirFiche("cadence") ? st("À l'heure", e.cadence_h ? e.cadence_h + " cav." : null) : "") + "</div>";
      if (crossActif())
        return '<div class="speaker">' + entete() + blocCross(5) + '<div class="colonnes dense"><div>' + blocCouple("Précédent", etat.precedent, true) +
          '</div><div>' + (voirFiche("classement") ? "<h2>Classement</h2>" + tableClassement(etat.classement, Math.max(3, lignesPossibles(48 + 33, 2.9))) : "") + "</div></div></div>";
      return '<div class="speaker">' + entete() + (dressageActif() ? blocDressage() : carteCouple()) + '<div class="colonnes dense"><div><h2>Fiche du couple</h2><div class="fiche">' + (fiche || '<div class="vide">—</div>') + "</div>" + (historiqueCouple(c) || stats) +
        "</div><div>" + (voirFiche("precedent") ? blocCouple("Précédent", etat.precedent, true) : "") + (voirFiche("suivant") ? blocCouple("Suivant", etat.suivant) : "") +
        (voirFiche("classement") ? "<h2>Classement</h2>" + tableClassement(etat.classement, lignesPossibles(dressageActif() ? 60 : 48, 2.9)) : "") + "</div></div></div>";
    },
    classement: function () {
      // deux colonnes ; au-delà, des pages qui défilent seules toutes les 12 secondes
      var rows = classes(etat.classement), parCol = lignesPossibles(17, 4.75), parPage = parCol * 2;
      var pages = Math.max(1, Math.ceil(rows.length / parPage));
      if (page >= pages) page = 0;
      var morceau = rows.slice(page * parPage, page * parPage + parPage), moitie = Math.min(parCol, Math.ceil(morceau.length / 2));
      if (rows.length <= 8) moitie = morceau.length;
      var titre = "<h2>Classement" + (pages > 1 ? ' <span class="doux">· page ' + (page + 1) + " / " + pages + "</span>" : "") + "</h2>";
      var tete = entete() + '<div class="deux-lignes' + (pageChange ? " page" : "") + '">';
      pageChange = false;
      if (moitie >= morceau.length) return tete + titre + tableClassement(morceau, morceau.length) + "</div>";
      return tete + '<div class="colonnes"><div>' + titre + tableClassement(morceau.slice(0, moitie), moitie) +
        "</div><div><h2>&nbsp;</h2>" + tableClassement(morceau.slice(moitie), moitie) + "</div></div></div>";
    },
    depart: function () {
      var d = etat.depart || [], dos = (etat.couple || {}).dossard, ici = -1, html = "";
      for (var i = 0; i < d.length; i++) if (d[i].dossard === dos) ici = i;
      var n = lignesPossibles(14, 3.6), debut = Math.max(0, Math.min(ici - 2, d.length - n));
      var rows = d.slice(debut, debut + n);
      for (var j = 0; j < rows.length; j++) {
        var r = rows[j], k = debut + j;
        html += '<tr class="' + (k === ici ? "moi" : k < ici ? "passe" : "") + '"><td class="r"><span>' + esc(r.ordre) + '</span></td><td class="n' + (imgDrapeau(r.nation) ? " nd" : "") + '">' + natCellule(r.nation) +
          '</td><td class="d">' + esc(r.dossard) + '</td><td class="nm"><b>' + esc(r.cavalier) + "</b><span>" + esc(joliNom(r.cheval)) +
          '</span></td><td class="tp">' + esc(r.heure) + "</td></tr>";
      }
      return entete() + "<h2>Ordre de départ</h2>" + (html ? '<table class="liste">' + html + "</table>" : '<div class="vide">L\'ordre de départ n\'est pas encore publié.</div>');
    },
    incrustation: function () {
      var e = etat.epreuve || {};
      if (!(etat.couple || {}).dossard) return "";
      return '<div class="bas' + (anim.couple ? " entre" : "") + '">' + (e.nom ? '<div class="tiers-epreuve">' + esc(e.nom) + "</div>" : "") + carteCouple("tiers") + "</div>";
    },
    carriere: function () {
      // tableau de carrière (piste, détente) : heure du jour, puis le décompte de 45 s ou le chrono, en très grand
      var c = etat.couple || {}, e = etat.epreuve || {}, p = etat.precedent || {};
      var der = p.dossard ? esc(p.dossard) + "  " + esc(p.cavalier) + (rangTexte(p.rang, true) ? "  ·  " + rangTexte(p.rang, true) : "") + (p.temps !== undefined && p.temps !== null ? "  ·  " + tempsTexte(p.temps) : "") : "";
      return '<div class="tableau etat-' + esc((etat.horloge || {}).state) + '"><div class="hj">' + heureDuJour() + '</div><div class="chrono"><div class="t">' + chronoTexte() + "</div></div>" +
        '<div class="ec">' + (c.dossard ? "<b>" + esc(c.dossard) + "</b>  " + esc(c.cavalier) + (c.cheval ? "  ·  " + esc(joliNom(c.cheval)) : "") : esc(e.nom || "")) + "</div>" +
        (der ? '<div class="der">Dernier : ' + der + "</div>" : "") + "</div>";
    },
    parcours: function () { return ""; },
    multi: function () { return colonnesPistes(false); },
    multi_classement: function () { return colonnesPistes(true); },
    presentation: function () {
      // présentation d'un couple, d'un étalon, tour d'honneur : peu de texte, le drapeau en grand
      var c = (etat.couple || {}).dossard ? etat.couple : (etat.suivant || {}).dossard ? etat.suivant : null, e = etat.epreuve || {};
      if (!c) return SCENES.attente();
      var drap = drapeauxActifs() ? DRAPEAUX.flottant(c.nation, "grand") : "", pays = drapeauxActifs() ? DRAPEAUX.nom(c.nation) : "";
      var origines = [c.race, c.age_cheval ? c.age_cheval + " ans" : "", c.pere ? "par " + c.pere + (c.mere ? " et " + c.mere : "") : ""].filter(function (x) { return x; }).join("  ·  ");
      var sur = [e.concours, e.nom].filter(function (x) { return x; }).join("  ·  ");
      return '<div class="presentation' + (drap ? "" : " sans-drapeau") + (anim.couple ? " entre" : "") + '">' + (sur ? '<div class="pr-sur">' + esc(sur) + "</div>" : "") +
        '<div class="pr-corps">' + (drap ? '<div class="pr-drapeau">' + drap + "</div>" : "") +
        '<div class="pr-qui"><div class="pr-dos">Dossard <b>' + esc(c.dossard) + "</b>" + (c.nation ? '<span class="pr-nat">' + esc(pays || c.nation) + "</span>" : "") + "</div>" +
        '<div class="pr-cav">' + esc(c.cavalier) + '</div><div class="pr-trait"></div><div class="pr-chv">' + esc(joliNom(c.cheval)) + "</div>" +
        (origines ? '<div class="pr-orig">' + esc(origines) + "</div>" : "") + (c.club ? '<div class="pr-orig">' + esc(c.club) + "</div>" : "") + "</div></div></div>";
    },
    remise: function () {
      var rows = classes(etat.classement), e = etat.epreuve || {}, podium = [], suite = "";
      for (var i = 0; i < rows.length; i++) if (!/el|ab|re/i.test(rows[i].points || rows[i].rang || "")) podium.push(rows[i]);
      if (!podium.length) return entete() + '<div class="vide">Le podium s\'affichera avec le classement.</div>';
      var ordre = portrait() ? [0, 1, 2] : [1, 0, 2], marches = "";
      for (var k = 0; k < ordre.length; k++) {
        var r = podium[ordre[k]];
        if (!r) continue;
        var n = parseInt(r.rang, 10) || ordre[k] + 1, d = drapeauxActifs() ? DRAPEAUX.flottant(r.nation, "moyen") : "";
        marches += '<div class="marche m' + (ordre[k] + 1) + '"><div class="md">' + (d || '<div class="flottant moyen vide-d"></div>') + "</div>" +
          '<div class="mr">' + n + "<sup>" + suf(n) + "</sup></div>" +
          '<div class="mc">' + esc(r.cavalier) + '</div><div class="mh">' + esc(joliNom(r.cheval)) + "</div>" +
          (r.nation ? '<div class="mn">' + esc((drapeauxActifs() && DRAPEAUX.nom(r.nation)) || r.nation) + "</div>" : "") + "</div>";
      }
      var reste = [];   // les places suivantes ne s'affichent plus : le podium seul, plus lisible
      for (var j = 0; j < reste.length; j++)
        suite += '<div class="rs"><b>' + esc(rangTexte(reste[j].rang, true)) + "</b>" + imgDrapeau(reste[j].nation) + "<span>" + esc(reste[j].cavalier) + "</span><i>" + esc(joliNom(reste[j].cheval)) + "</i></div>";
      return '<div class="remise"><div class="rm-titre"><small>Remise des prix' + (e.concours ? "  ·  " + esc(e.concours) : "") + "</small>" + esc(e.nom || "") + "</div>" +
        '<div class="podium-r">' + marches + "</div>" + (suite ? '<div class="rm-suite">' + suite + "</div>" : "") + "</div>";
    },
    attente: function () {
      var e = etat.epreuve || {}, d = new Date();
      var hh = (d.getHours() < 10 ? "0" : "") + d.getHours() + ":" + (d.getMinutes() < 10 ? "0" : "") + d.getMinutes();
      var ligne = (etat.nb_carrieres > 1 && etat.carriere ? etat.carriere + (e.nom ? "  ·  " : "") : "") + (e.nom || "");
      return '<div class="attente"><div class="c">' + esc(e.concours || "Bienvenue") + '</div><div class="trait"></div><div class="e">' +
        esc(ligne) + '</div><div class="h">' + hh + "</div></div>";
    }
  };
  // ---------------------------------------------------------------- plusieurs pistes sur un écran
  // Chaque colonne a son propre état (etat.pistes[i]) ; on dessine avec les mêmes blocs que l'écran simple.
  function avec(e, fn) {
    var sEtat = etat, sAnim = anim;
    etat = e; anim = { couple: false, resultat: false, precedent: false, flash: null };
    try { return fn(); } finally { etat = sEtat; anim = sAnim; }
  }
  function trouverPiste(id) {
    var ps = etat.pistes || [];
    for (var i = 0; i < ps.length; i++) if (ps[i].id === id) return ps[i];
    return null;
  }
  function entetePiste(e) {
    var ep = e.epreuve || {}, puces = "";
    if (ep.partis !== null && ep.partis !== undefined && ep.partants) puces += '<span class="puce"><b>' + esc(ep.partis) + "</b> / " + esc(ep.partants) + "</span>";
    if (ep.temps_accorde) puces += '<span class="puce">TA <b>' + esc(ep.temps_accorde) + " s</b></span>";
    return '<div class="entete-m"><div class="sur">' + esc(e.carriere || "") + (ep.epreuve ? "  ·  Épreuve " + esc(ep.epreuve) : "") +
      '</div><div class="nom">' + esc(ep.nom || "En attente du chrono") + '</div><div class="infos">' + puces + "</div></div>";
  }
  function colonnesPistes(classementSeul) {
    var ps = etat.pistes || [];
    if (!ps.length) return SCENES.attente();
    var n = Math.min(4, ps.length), lignes = n === 4 ? 2 : 1;
    var fs = parseFloat(document.documentElement.style.fontSize || 16);
    var hauteur = window.innerHeight / lignes / fs;   // hauteur d'une colonne, en rem
    var nb = Math.max(3, Math.floor((hauteur - (classementSeul ? 13 : 27)) / 3.35));
    var html = '<div class="multi n' + n + (classementSeul ? " seul" : "") + '">';
    for (var i = 0; i < n; i++) {
      var p = ps[i];
      html += '<div class="piste-m" data-p="' + esc(p.id) + '">' + avec(p, function () {
        return entetePiste(p) + (classementSeul ? "" : carteCouple()) + "<h2>Classement</h2>" + tableClassement(p.classement, nb);
      }) + "</div>";
    }
    return html + "</div>";
  }
  function ticPistes() {
    var cols = document.querySelectorAll(".piste-m");
    for (var i = 0; i < cols.length; i++) {
      var p = trouverPiste(cols[i].getAttribute("data-p"));
      if (!p) continue;
      var txt = avec(p, chronoTexte), el = cols[i].querySelectorAll(".chrono .t");
      for (var j = 0; j < el.length; j++) if (el[j].innerHTML !== txt) el[j].innerHTML = txt;
    }
  }
  function majPiste(ev) {
    // événement d'une des carrières d'un écran « plusieurs pistes » ; renvoie vrai s'il faut redessiner
    var e = trouverPiste(ev.piste), t = ev.type;
    if (!e) return false;
    if (t === "class.info") { e.epreuve = ev; e.couple = {}; e.precedent = {}; e.suivant = {}; e.classement = []; e.horloge = {}; }
    else if (t === "class.progress") e.epreuve = ev;
    else if (t === "rider.on_course") e.couple = ev;
    else if (t === "rider.previous") e.precedent = ev;
    else if (t === "rider.next") e.suivant = ev.dossard ? ev : {};
    else if (t === "run.result") { if (e.couple && e.couple.dossard === ev.dossard) e.couple.resultat = ev; }
    else if (t === "ranking") e.classement = ev.lignes;
    else if (t === "startlist") e.depart = ev.lignes;
    else if (t === "clock") {
      var avant = (e.horloge || {}).state, fautes = (e.horloge || {}).faults, ancien = e.horloge || {};
      var inters = ev.intermediaires || [], nouvel = inters.length > (ancien.intermediaires || []).length;
      e.horloge = { state: ev.state, time: ev.time, faults: ev.faults, recu: Date.now(), intermediaires: inters,
                    interRecu: nouvel ? Date.now() : (ev.state === "en_course" ? ancien.interRecu : 0) };
      return avant !== ev.state || fautes !== ev.faults || nouvel;   // le temps seul avance via tic()
    } else return false;
    return true;
  }
  function preparerPistes(ps) {
    var out = [];
    for (var i = 0; i < (ps || []).length; i++) {
      var s = ps[i], h = s.horloge || {};
      out.push({ id: s.id, carriere: s.carriere, epreuve: s.epreuve || {}, couple: s.couple || {}, precedent: s.precedent || {},
        suivant: s.suivant || {}, classement: s.classement || [], depart: s.depart || [],
        horloge: { state: h.state, time: h.time, faults: h.faults, recu: Date.now() - (h.age_ms || 0) } });
    }
    return out;
  }

  // ---------------------------------------------------------------- compte à rebours (centre de contrôle)
  var decompte = null, decompteFin = 0;
  function pourMoi(liste) { return !liste || liste.indexOf(NOM) >= 0; }
  function poserDecompte(d) {
    decompte = d && pourMoi(d.ecrans) ? d : null;
    decompteFin = decompte ? Date.now() + (d.reste_ms || 0) : 0;
    var z = $("decompte");
    if (!z) return;
    if (!decompte) { z.className = "cache"; z.innerHTML = ""; return; }
    z.innerHTML = '<div class="boite"><div class="dt">' + esc(decompte.titre) + '</div><div class="dn"></div>' +
      (decompte.sous_titre ? '<div class="ds">' + esc(decompte.sous_titre) + "</div>" : "") + "</div>";
    z.className = "";
    ticDecompte();
  }
  function ticDecompte() {
    if (!decompte) return;
    var reste = Math.ceil((decompteFin - Date.now()) / 1000), z = $("decompte"), n = z && z.querySelector(".dn");
    if (!n) return;
    if (reste < -4) { poserDecompte(null); return; }
    var txt;
    if (reste <= 0) txt = "C'est parti !";
    else {
      var h = Math.floor(reste / 3600), m = Math.floor(reste % 3600 / 60), sec = reste % 60;
      txt = (h ? h + ":" + (m < 10 ? "0" : "") : "") + m + ":" + (sec < 10 ? "0" : "") + sec;
    }
    if (n.innerHTML !== txt) { n.innerHTML = txt; z.className = reste <= 0 ? "fini" : reste <= 10 ? "bientot" : ""; }
  }

  // ---------------------------------------------------------------- vidéo (fichier ou flux en direct)
  var videoCle = "", hls = null, relance = null;
  // Son des vidéos : un navigateur refuse le son tant que personne n'a touché la page. On joue alors sans le son,
  // on affiche « Toucher l'écran pour le son » et on prévient le centre de contrôle. Au premier clic, appui sur une
  // touche ou toucher, le son revient (et reste permis pour les vidéos suivantes tant que la page n'est pas rechargée).
  var sonPermis = false, videoSon = null;
  function signalerSon(bloque) {
    if (APERCU) return;
    try {
      var x = new XMLHttpRequest();
      x.open("POST", "/api/ecran/son", true);
      x.setRequestHeader("Content-Type", "application/json");
      x.send(JSON.stringify({ ecran: NOM, bloque: bloque }));
    } catch (e) { }
  }
  function bandeauSon(el, montrer) {
    var b = el.parentNode && el.parentNode.querySelector(".son-bloque");
    if (montrer && !b && el.parentNode) {
      b = document.createElement("div");
      b.className = "son-bloque";
      b.textContent = "🔇 Toucher l'écran pour activer le son";
      el.parentNode.appendChild(b);
    } else if (!montrer && b) b.parentNode.removeChild(b);
  }
  function debloquerSon() {
    sonPermis = true;
    var el = videoSon;
    if (!el || !el.muted || !el.parentNode) return;
    el.muted = false;
    var p = el.play();
    if (p && p.then) p.then(function () { bandeauSon(el, false); signalerSon(false); }, function () { });
    else { bandeauSon(el, false); signalerSon(false); }
  }
  ["pointerdown", "touchstart", "mousedown", "keydown", "click"].forEach(function (t) {
    document.addEventListener(t, debloquerSon, true);
  });
  function poserVideo(v) {
    var z = $("video");
    if (!z) return;
    v = v && pourMoi(v.ecrans) ? v : null;
    var cle = v ? v.url + "|" + v.depuis : "";
    if (cle === videoCle) return;
    videoCle = cle;
    clearTimeout(relance);
    if (hls) { try { hls.destroy(); } catch (e) { } hls = null; }
    z.innerHTML = "";
    videoSon = null;
    if (!v) { z.className = "cache"; return; }
    z.className = v.place === "coin" ? "coin" : "plein";
    if (APERCU) { z.innerHTML = '<div class="apercu-video">▶ ' + esc(v.nom) + "</div>"; return; }   // pas de flux vidéo dans les aperçus de la régie
    var el = document.createElement("video");
    el.setAttribute("playsinline", ""); el.setAttribute("autoplay", "");
    el.loop = !!v.boucle && !v.flux; el.muted = !v.son;
    if (v.son) { el.volume = 1; videoSon = el; }
    z.appendChild(el);
    var lancer = function () {
      var p = el.play();
      // le navigateur refuse le son sans un geste sur la page : on joue sans le son plutôt que pas du tout,
      // et on demande de toucher l'écran (debloquerSon remet le son)
      if (p && p.catch) p.catch(function (err) {
        if (el.muted || !el.parentNode || (err && err.name === "AbortError")) return;
        el.muted = true;
        var q = el.play(); if (q && q.catch) q.catch(function () { });
        bandeauSon(el, true); signalerSon(true);
      });
    };
    el.addEventListener("ended", function () { if (!el.loop) { videoCle = "fin|" + cle; z.className = "cache"; z.innerHTML = ""; } });
    if (!v.flux) {
      el.addEventListener("loadedmetadata", function () {
        var t = (v.ecoule_ms || 0) / 1000;   // écran allumé en cours de route : on rejoint la vidéo où elle en est
        if (t > 1 && el.duration && isFinite(el.duration)) {
          if (v.boucle) el.currentTime = t % el.duration;
          else if (t < el.duration - .5) el.currentTime = t;
          else { videoCle = "fin|" + cle; z.className = "cache"; z.innerHTML = ""; }
        }
      });
    }
    var hlsUrl = /\.m3u8(\?|$)/i.test(v.url);
    if (hlsUrl && !el.canPlayType("application/vnd.apple.mpegurl")) {
      chargerHls(function () {
        if (videoCle !== cle || !window.Hls || !window.Hls.isSupported()) { if (videoCle === cle) z.innerHTML = '<div class="apercu-video">Ce navigateur ne lit pas les flux en direct</div>'; return; }
        hls = new window.Hls({ liveSyncDurationCount: 3 });
        hls.on(window.Hls.Events.ERROR, function (_, d) {
          if (!d.fatal) return;
          // flux pas encore lancé ou coupé : on réessaie toutes les 5 secondes
          try { hls.destroy(); } catch (e) { } hls = null;
          relance = setTimeout(function () { if (videoCle === cle) { videoCle = ""; poserVideo(v); } }, 5000);
        });
        hls.loadSource(v.url); hls.attachMedia(el);
        hls.on(window.Hls.Events.MANIFEST_PARSED, lancer);
      });
    } else {
      el.src = v.url;
      el.addEventListener("error", function () {
        if (v.flux) relance = setTimeout(function () { if (videoCle === cle) { videoCle = ""; poserVideo(v); } }, 5000);
      });
      lancer();
    }
  }
  var hlsCharge = false, hlsAttente = [];
  function chargerHls(fn) {
    if (window.Hls) return fn();
    hlsAttente.push(fn);
    if (hlsCharge) return;
    hlsCharge = true;
    var sc = document.createElement("script");
    sc.src = "/web/lib/hls.light.min.js";
    sc.onload = sc.onerror = function () { var f = hlsAttente; hlsAttente = []; for (var i = 0; i < f.length; i++) f[i](); };
    document.getElementsByTagName("head")[0].appendChild(sc);
  }

  var page = 0, pageChange = false;
  setInterval(function () {
    if (vu.sceneReelle !== "classement") return;
    var parPage = lignesPossibles(17, 4.75) * 2;
    if (classes(etat.classement).length > parPage) { page++; pageChange = true; dessiner(); }
  }, 12000);
  function portrait() { return document.documentElement.className.indexOf("portrait") >= 0; }

  var dessinEnAttente = false, sortieEnCours = false;
  function dessiner() {
    if (dessinEnAttente || sortieEnCours) return;
    dessinEnAttente = true;
    setTimeout(function () {
      dessinEnAttente = false;
      var s = SCENE_FORCEE || scene;
      if (SCENES[s] === undefined && s.indexOf("mep:") !== 0) s = "public";
      // bandeau vidéo : l'ancien couple sort avant que le nouveau n'entre
      var cleAvant = vu.couple;
      preparerAnimations(s);
      var bas = document.querySelector("#scene .bas");
      if (s === "incrustation" && bas && cleAvant && vu.couple !== cleAvant) {
        bas.className += " sort";
        sortieEnCours = true;
        var c = anim.couple, r = anim.resultat;
        setTimeout(function () { sortieEnCours = false; anim.couple = c || !!vu.couple; anim.resultat = r; rendre(s); }, 450);
        return;
      }
      rendre(s);
      styleEcran();
    }, 30);
  }
  var outilsMep = {
    chrono: function () { return chronoTexte() || (EDITEUR && exemple ? "41.3" : ""); }, joliNom: joliNom, rangTexte: rangTexte, tempsTexte: tempsTexte,
    carte: function () { return carteCouple(); }, entete: function () { return entete(); },
    vis: {}, relancer: function (ms) { setTimeout(dessiner, ms); }   // blocs affichés ou non selon l'étape du tour
  };
  var mepVue = "";
  function rendre(s) {
    if (s.indexOf("mep:") === 0 || EDITEUR) {
      var m = EDITEUR ? mepEditeur : mep;
      if (!m) { s = "public"; } else {
        outilsMep.editeur = EDITEUR; outilsMep.fondVert = opts.fond_vert;
        if ((m.id || "") !== mepVue) { outilsMep.vis = {}; mepVue = m.id || ""; }   // autre mise en page : pas d'effet au premier dessin
        // éditeur : « toutes les étapes » montre tous les blocs, sinon l'étape choisie pour l'aperçu
        outilsMep.toutes = EDITEUR && !etapeApercu; outilsMep.etape = EDITEUR && etapeApercu !== "direct" ? etapeApercu : "";
        document.body.className = "mep-scene" + (m.fond === "vert" || m.fond === "transparent" ? " mep-vert" : "");
        taille();
        $("scene").className = s !== vu.scene ? "fondu" : "";
        $("scene").innerHTML = recolorer(MEP.rendre(m, EDITEUR && exemple ? MEP.EXEMPLE : etat, outilsMep));
        if (typeof DRAPEAUX !== "undefined" && DRAPEAUX.dessiner) DRAPEAUX.dessiner();
        vu.scene = s; vu.sceneReelle = s;
        return;
      }
    }
    if (s === "parcours") {
      // simulation 3D en plein écran : on ne recharge que si le parcours choisi change
      var pa = etat.parcours || {}, src = "/parcours3d?id=" + encodeURIComponent(pa.id || "exemple") + "&mode=" + (pa.barrage ? "barrage" : "parcours") + (pa.v ? "&v=" + pa.v : "") + (APERCU ? "&qualite=basse" : params.qualite ? "&qualite=" + encodeURIComponent(params.qualite) : "");
      document.body.className = "plein";
      var f = $("scene").querySelector("iframe");
      if (!f || f.getAttribute("src") !== src) $("scene").innerHTML = '<iframe src="' + src + '" style="position:absolute;left:0;top:0;width:100%;height:100%;border:0"></iframe>';
      vu.scene = s; vu.sceneReelle = s;
      return;
    }
    document.body.className = (s === "incrustation" ? "incrustation" : MULTI[s] ? "multi-pistes" : "") + (opts.masquer_horloge ? " sans-chrono" : "");
    taille();
    var z = $("scene"), nouvelleScene = s !== vu.scene;
    var html = SCENES[s]();
    if (s === "public" && (vide(etat.epreuve) || !etat.epreuve.nom)) s = "attente";
    z.className = (nouvelleScene ? "fondu" : "") + (s === "attente" && !nouvelleScene && vu.sceneReelle === "attente" ? " calme" : "");
    z.innerHTML = html;
    if (typeof DRAPEAUX !== "undefined" && DRAPEAUX.dessiner) DRAPEAUX.dessiner();   // pas d'image vide entre deux mises à jour
    vu.scene = SCENE_FORCEE || scene;
    vu.sceneReelle = s;
  }
  setInterval(function () { if (vu.sceneReelle === "attente" || String(vu.sceneReelle).indexOf("mep:") === 0) dessiner(); }, 20000);

  function dessinerMessage() {
    var m = $("message");
    var pourMoi = message && message.texte && (!message.ecrans || message.ecrans.indexOf(NOM) >= 0);
    m.className = pourMoi ? "" : "cache";
    m.innerHTML = pourMoi ? esc(message.texte) : "";
  }
  function poserMessage(m) {
    message = m && m.texte ? m : null;
    messageFin = message ? Date.now() + (m.reste_ms || 0) : 0;
    dessinerMessage();
  }

  // ---------------------------------------------------------------- événements
  function appliquer(ev) {
    var t = ev.type;
    if (ev.piste && t !== "init") { if (majPiste(ev)) dessiner(); return; }
    if (t === "decompte") { poserDecompte(ev.decompte); return; }
    if (t === "video") { poserVideo(ev.video); return; }
    if (t === "init") {
      appliquerEtat(ev.etat);
      changerScene(ev.scene);
      premierInit = false;
      noterResultatsConnus();
    } else if (t === "scene") {
      if (changerScene(ev.scene)) return;
    } else if (t === "fiche_speaker") {
      etat.ficheCaches = ev.caches || [];
      if (ev.colonnes) etat.ficheColonnes = ev.colonnes;
      if (scene !== "speaker") return;
    } else if (t === "class.info") {
      etat.epreuve = ev; etat.couple = {}; etat.precedent = {}; etat.suivant = {}; etat.classement = []; etat.horloge = {};
    } else if (t === "class.progress") {
      etat.epreuve = ev;
    } else if (t === "rider.on_course") {
      etat.couple = ev;
    } else if (t === "rider.previous") {
      etat.precedent = ev;
    } else if (t === "rider.next") {
      etat.suivant = ev.dossard ? ev : {};
    } else if (t === "run.result") {
      if (etat.couple && etat.couple.dossard === ev.dossard) etat.couple.resultat = ev;
      resultatEnDirect(ev);
    } else if (t === "clock") {
      var avantPg = cleProgressif(etat.horloge);
      etat.horloge = poserPhase1({ state: ev.state, time: ev.time, faults: ev.faults, recu: Date.now(), progressif: ev.progressif || null, obstacles: ev.obstacles || null,
                                   phase_1: ev.phase_1 == null ? null : ev.phase_1 }, etat.horloge);
      var chrono = document.querySelector(".chrono");
      if (avantPg !== cleProgressif(etat.horloge)) { dessiner(); return; }
      // l'heure seule change souvent : on ne redessine tout que si l'état change
      if (chrono && chrono.parentNode && chrono.parentNode.className.indexOf("etat-" + ev.state) >= 0) {
        var f = document.querySelectorAll(".chrono .fp");
        for (var i = 0; i < f.length; i++) f[i].innerHTML = fautesTexte();
        tic();
        return;
      }
    } else if (t === "ranking") {
      etat.classement = ev.lignes;
    } else if (t === "startlist") {
      etat.depart = ev.lignes;
    } else if (t === "cross") {
      poserCross(ev.cross);
    } else if (t === "dressage") {
      recevoirDressage(ev.dressage);
    } else if (t === "message") {
      poserMessage(ev); return;
    } else if (t === "identifier") {
      if (!APERCU) identifier(); return;
    } else if (t === "renomme") {
      // écran renommé dans le Centre de contrôle : la page change d'adresse, le téléviseur retient le nouveau nom
      if (APERCU || RELAIS || EDITEUR || !ev.nom) return;
      try { if (localStorage.getItem("hm.ecran") === NOM) localStorage.setItem("hm.ecran", ev.nom); } catch (e) { }
      location.replace("/ecran/" + encodeURIComponent(ev.nom) + location.search); return;
    } else if (t === "transition") {
      jouerTransition(ev); return;
    } else {
      return;
    }
    dessiner();
  }
  function appliquerEtat(s) {
    if (!s) return;
    etat.epreuve = s.epreuve || {}; etat.couple = s.couple || {}; etat.precedent = s.precedent || {};
    etat.suivant = s.suivant || {}; etat.classement = s.classement || []; etat.depart = s.depart || [];
    etat.carriere = s.carriere || ""; etat.nb_carrieres = s.nb_carrieres || 0;
    etat.parcours = s.parcours || {};
    if (s.fiche_speaker) etat.ficheCaches = s.fiche_speaker;
    if (s.fiche_colonnes) etat.ficheColonnes = s.fiche_colonnes;
    poserCross(s.cross);
    recevoirDressage(s.dressage);
    etat.pistes = preparerPistes(s.pistes);
    poserDecompte(s.decompte);
    poserVideo(s.video);
    if (s.affichage) appliquerAffichage(s.affichage);
    var h = s.horloge || {};
    etat.horloge = poserPhase1({ state: h.state, time: h.time, faults: h.faults, recu: Date.now() - (h.age_ms || 0), progressif: h.progressif || null, obstacles: h.obstacles || null,
                                 phase_1: h.phase_1 == null ? null : h.phase_1 }, etat.horloge);
    poserMessage(s.message);
    dessiner();
  }

  // ---------------------------------------------------------------- réglages de l'écran (Administration)
  var THEMES = {   // fond, haut du dégradé, carte, panneaux, bordures
    nuit: ["#08101d", "#13223d", "#172743", "#111d33", "#24375a"],
    noir: ["#000000", "#121212", "#1c1c1c", "#141414", "#2c2c2c"],
    marine: ["#03122b", "#0b2a5c", "#0f3470", "#0a2550", "#1d4a8c"],
    bordeaux: ["#17060a", "#3d0f17", "#4a1520", "#33101a", "#6a2533"],
    foret: ["#06140d", "#0f3020", "#143d29", "#0f2b1d", "#245a3e"],
    ardoise: ["#14171c", "#262b33", "#2f3540", "#232830", "#3b4350"]
  };
  var cssOrigine = null, cleStyle = "";
  function hexRgb(h) { return [parseInt(h.substr(1, 2), 16), parseInt(h.substr(3, 2), 16), parseInt(h.substr(5, 2), 16)]; }
  function eclaircir(h, k) {
    var c = hexRgb(h), out = "#";
    for (var i = 0; i < 3; i++) { var v = Math.round(c[i] + (255 - c[i]) * k); out += (v < 16 ? "0" : "") + v.toString(16); }
    return out;
  }
  function assombrir(h, k) {
    var c = hexRgb(h), out = "#";
    for (var i = 0; i < 3; i++) { var v = Math.round(c[i] * (1 - k)); out += (v < 16 ? "0" : "") + v.toString(16); }
    return out;
  }
  // thème « perso » (couleur de l'organisateur) : la couleur, assombrie, pour que le texte blanc reste lisible de loin
  function nuances(h) {
    var c = hexRgb(h), lum = (.2126 * c[0] + .7152 * c[1] + .0722 * c[2]) / 255, k = Math.max(0, 1 - .2 / Math.max(lum, .05));
    return [assombrir(h, .55 + .4 * k), assombrir(h, .3 + .55 * k), assombrir(h, .22 + .55 * k), assombrir(h, .38 + .52 * k), assombrir(h, .05 + .45 * k)];
  }
  function hexOk(h) { return /^#[0-9a-f]{6}$/i.test(h || ""); }
  function melanger(h, f, k) {   // h vers f, de k (0 à 1)
    var a = hexRgb(h), b = hexRgb(f), out = "#";
    for (var i = 0; i < 3; i++) { var v = Math.round(a[i] + (b[i] - a[i]) * k); out += (v < 16 ? "0" : "") + v.toString(16); }
    return out;
  }
  // Palette de l'écran : fond (principale), accent (secondaire), décor (filets, barres), texte. Les couleurs d'origine
  // de ecran.css et des mises en page sur mesure sont remplacées une à une : la conception des pages ne change pas.
  var palette = { cle: "", map: null };
  function calculerPalette() {
    var th = opts.theme === "perso" && hexOk(opts.fond) ? nuances(opts.fond.toLowerCase()) : THEMES[opts.theme] || THEMES.nuit;
    var acc = hexOk(opts.accent) ? opts.accent.toLowerCase() : "#e6b84c";
    var dec = hexOk(opts.decor) ? opts.decor.toLowerCase() : acc;
    var txt = hexOk(opts.couleur_texte) ? opts.couleur_texte.toLowerCase() : "#f4f6fa";
    var vert = hexOk(opts.fond_vert) ? opts.fond_vert.toLowerCase() : "#00b140";
    var cle = [th.join(), acc, dec, txt, vert].join("|");
    if (cle === palette.cle) return palette;
    var m = {}, base = THEMES.nuit;
    for (var i = 0; i < base.length; i++) m[base[i]] = th[i];
    m["(8,16,29"] = "(" + hexRgb(th[0]).join(","); m["(17,29,51"] = "(" + hexRgb(th[3]).join(",");   // fonds en rgba()
    m["#e6b84c"] = acc; m["#f5d68a"] = eclaircir(acc, .45); m["(230,184,76"] = "(" + hexRgb(acc).join(",");
    m["#e6b84d"] = dec; m["(230,184,77"] = "(" + hexRgb(dec).join(",");
    if (txt !== "#f4f6fa") {
      m["#f4f6fa"] = txt; m["#c8d1e0"] = melanger(txt, th[0], .2); m["#8e9bb3"] = melanger(txt, th[0], .45);
      m["(142,155,179"] = "(" + hexRgb(m["#8e9bb3"]).join(",");
    }
    m["#00b140"] = vert;
    var neutre = true;
    for (var k in m) if (m[k] !== k && !(k === "#e6b84d" && m[k] === "#e6b84c") && !(k === "(230,184,77" && m[k] === "(230,184,76")) neutre = false;
    palette = { cle: cle, map: neutre ? null : m, fond: th[0], vert: vert };
    return palette;
  }
  function recolorer(s) {   // un seul passage : une couleur remplacée n'est jamais remplacée une seconde fois
    var p = calculerPalette();
    if (!p.map) return s;
    return s.replace(/#[0-9a-fA-F]{6}\b|\((?:230,184,7[67]|8,16,29|17,29,51|142,155,179)\b/g, function (c) { var v = p.map[c.toLowerCase()]; return v === undefined ? c : v; });
  }
  function styleEcran() {
    var p = calculerPalette();
    document.documentElement.style.background = document.body.className.indexOf("incrustation") >= 0 || document.body.className.indexOf("mep-vert") >= 0 ? p.vert : p.fond;
    if (p.cle === cleStyle) return;
    var el = $("style-perso");
    if (!p.map) { cleStyle = p.cle; if (el) el.parentNode.removeChild(el); return; }
    if (cssOrigine === null) {
      // on reprend la feuille de style d'origine en changeant ses couleurs : marche sur tous les navigateurs
      var x = new XMLHttpRequest();
      x.open("GET", "/web/ecran.css", true);
      x.onload = function () { cssOrigine = x.responseText.replace(/@import[^;]+;/, ""); styleEcran(); };
      x.send();
      return;
    }
    cleStyle = p.cle;
    if (!el) { el = document.createElement("style"); el.id = "style-perso"; document.getElementsByTagName("head")[0].appendChild(el); }
    el.textContent = recolorer(cssOrigine);
  }
  function appliquerAffichage(a) {
    opts = a.options || {};
    mep = a.mise_en_page || null;
    if (typeof I18N !== "undefined") I18N.appliquer(opts.langue || "fr");   // textes fixes de l'écran (pas les noms)
    var logo = $("logo");
    if (opts.logo && opts.logo_place !== "aucun") {
      if (!logo) { logo = document.createElement("div"); logo.id = "logo"; document.body.appendChild(logo); }
      if (logo.getAttribute("data-src") !== opts.logo) { logo.innerHTML = '<img src="' + esc(opts.logo) + '" alt="">'; logo.setAttribute("data-src", opts.logo); }
      logo.className = opts.logo_place || "haut-droite";
      logo.style.width = (+opts.logo_taille || 10) + "rem";
    } else if (logo) logo.parentNode.removeChild(logo);
    taille();
  }

  // éditeur de mise en page : la page Administration envoie la mise en page à dessiner
  var mepEditeur = null, exemple = true, etapeApercu = "";
  if (EDITEUR) window.addEventListener("message", function (ev) {
    if (ev.origin !== location.origin || !ev.data || ev.data.type !== "mep") return;
    mepEditeur = ev.data.mise_en_page; exemple = ev.data.exemple !== false; etapeApercu = ev.data.etape || "";
    if (ev.data.etat) { var e = ev.data.etat; delete e.affichage; appliquerEtat(e); }
    appliquerAffichage({ options: ev.data.options || {} });
    dessiner();
  });

  // ---------------------------------------------------------------- identification (bouton de la régie)
  var finIdent = null;
  function identifier() {
    var d = $("identifier");
    if (!d) { d = document.createElement("div"); d.id = "identifier"; document.body.appendChild(d); }
    d.innerHTML = "<div class=\"boite\"><small>Cet écran s'appelle</small>" + esc(NOM) + "</div>";
    d.className = "";
    clearTimeout(finIdent);
    finIdent = setTimeout(function () { d.className = "cache"; }, 5000);
  }

  // ---------------------------------------------------------------- transition
  var finTransition = null;
  function jouerTransition(ev) {
    var z = $("transition"), style = ev.style || "volet";
    var texte = ev.texte || (etat.epreuve || {}).concours || (etat.epreuve || {}).nom || "";
    clearTimeout(finTransition);
    z.className = "";
    var html = "";
    if (style === "volet") html = '<div class="v1"></div><div class="v2"></div><div class="v3"></div>';
    else if (style === "rideau") html = '<div class="r1"></div><div class="r2"></div><div class="rt">' + esc(texte) + "</div>";
    else if (style === "eclat") html = '<div class="e1"></div><div class="e2"></div>';
    else if (style === "bandes") { for (var i = 0; i < 6; i++) html += '<div class="b b' + i + '"></div>'; }
    else { style = "logo"; html = '<div class="l1"><div class="lt">' + esc(texte) + "</div></div>"; }
    z.innerHTML = html;
    void z.offsetWidth; // relance l'animation même si la précédente n'était pas finie
    z.className = "t-" + style;
    finTransition = setTimeout(function () { z.className = ""; z.innerHTML = ""; }, 2600);
  }

  // ---------------------------------------------------------------- changement d'affichage
  // L'écran passe d'une scène à l'autre derrière une animation : la nouvelle scène est posée
  // quand l'animation couvre tout l'écran (COUVRE : instant en ms), puis l'animation se retire.
  var COUVRE = { volet: 800, rideau: 820, logo: 620, eclat: 640, bandes: 700 };
  var sceneVisee = null, finScene = null, premierInit = true;
  function changerScene(nouvelle) {
    if (!nouvelle) return false;
    var actuelle = sceneVisee || scene;
    if (nouvelle === actuelle) return false;
    var st = opts.transition_scene || "volet";
    if (premierInit || SCENE_FORCEE || EDITEUR || !COUVRE[st]) {
      clearTimeout(finScene); sceneVisee = null; scene = nouvelle;
      return false;
    }
    sceneVisee = nouvelle;
    jouerTransition({ style: st });
    clearTimeout(finScene);
    finScene = setTimeout(function () { scene = sceneVisee || scene; sceneVisee = null; dessiner(); }, COUVRE[st]);
    return true;
  }

  // ---------------------------------------------------------------- fêtes : sans faute, 1re place
  var fetesVues = {}, finFete = null, resultatFete = null, minuteurFete = null;
  function cleRes(c) { return (c.epreuve || (etat.epreuve || {}).epreuve || "") + "/" + (c.manche || 1) + "/" + c.dossard; }
  function noterResultatsConnus() {
    var c = etat.couple || {};
    if (c.dossard && c.resultat) fetesVues[cleRes(c)] = 1;
  }
  function resultatEnDirect(ev) {
    if (!ev.dossard || fetesVues[cleRes(ev)]) return;
    // le classement suit de peu le résultat : on attend qu'il arrive pour savoir si le couple passe seul en tête
    resultatFete = ev;
    clearTimeout(minuteurFete);
    minuteurFete = setTimeout(function () {
      var r = resultatFete; resultatFete = null;
      if (!r || fetesVues[cleRes(r)]) return;
      fetesVues[cleRes(r)] = 1;
      var rang = String(r.rang || "");
      if (/el|ab|re|hc|dis/i.test(rang) || /el|ab/i.test(String(r.temps || ""))) return;
      var cl = etat.classement || [], autresEnTete = 0, autres = 0;
      for (var i = 0; i < cl.length; i++) {
        if (cl[i].dossard === r.dossard) continue;
        if (parseInt(cl[i].rang, 10) === 1) autresEnTete++;
        if (cl[i].points !== null || cl[i].temps !== null) autres++;
      }
      var e = etat.epreuve || {};
      if (parseInt(rang, 10) === 1 && !autresEnTete && (autres || +(e.partis || 0) > 1)) feter("tete", r);
      else if (r.penalites === 0) feter("sans-faute", r);
    }, 900);
  }
  function feter(sorte, r) {
    var s = vu.sceneReelle;
    if (opts.fetes === false || s === "parcours" || s === "attente" || s === "depart" || s === "presentation" || s === "remise") return;
    var z = $("fete");
    if (!z) { z = document.createElement("div"); z.id = "fete"; document.body.appendChild(z); }
    var titre = sorte === "tete" ? "Nouveau leader" : "Sans faute";
    var sous = esc(r.cavalier || "") + (r.cheval ? " · " + esc(joliNom(r.cheval)) : "");
    var html = '<div class="rayons"></div><div class="banniere"><div class="ft">' + titre + '</div>' +
      (sous ? '<div class="fs">' + sous + "</div>" : "") + "</div>";
    if (sorte === "tete" && s !== "incrustation") {
      var couleurs = ["#e6b84c", "#f5d68a", "#ffffff", "#5fd99b", "#e6b84d"].map(recolorer);
      for (var i = 0; i < 46; i++) {
        var dl = (Math.random() * 0.9).toFixed(2) + "s", du = (2.2 + Math.random() * 1.4).toFixed(2) + "s";
        html += '<i style="left:' + (Math.random() * 100).toFixed(1) + "%;background:" + couleurs[i % couleurs.length] +
          ";-webkit-animation-delay:" + dl + ";animation-delay:" + dl + ";-webkit-animation-duration:" + du + ";animation-duration:" + du + '"></i>';
      }
    }
    clearTimeout(finFete);
    z.className = "";
    z.innerHTML = html;
    void z.offsetWidth;
    z.className = "f-" + sorte + (s === "incrustation" ? " f-bas" : "");
    finFete = setTimeout(function () { z.className = "cache"; z.innerHTML = ""; }, 4200);
  }

  // ---------------------------------------------------------------- connexion
  // Signe de vie : sans lui, un écran fermé sans couper sa connexion (téléphone en veille, onglet fermé sur iPhone)
  // resterait compté comme connecté sur le serveur.
  var JETON = Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
  function brancher() {
    var url = "/flux?ecran=" + encodeURIComponent(NOM) + (APERCU ? "&apercu=1" : "") + "&jeton=" + JETON;
    if (window.EventSource) {
      var es;
      var ouvrir = function () {
        if (es) es.close();
        es = new EventSource(url);
        es.onopen = function () { $("hors-ligne").className = "cache"; };
        es.onerror = function () { $("hors-ligne").className = ""; };
        es.onmessage = function (m) { try { appliquer(JSON.parse(m.data)); } catch (e) { } };
      };
      ouvrir();
      var vivant = function () {
        if (!es || es.readyState !== 1) return;          // en cours de reconnexion : EventSource s'en occupe
        var x = new XMLHttpRequest();
        x.open("GET", "/api/vivant?jeton=" + JETON, true);
        x.onload = function () { try { if (JSON.parse(x.responseText).ok === false) ouvrir(); } catch (e) { } };   // flux fermé par le serveur
        x.send();
      };
      setInterval(vivant, 25000);
      document.addEventListener("visibilitychange", function () { if (!document.hidden) vivant(); });
      window.addEventListener("pagehide", function () {
        try { if (navigator.sendBeacon) navigator.sendBeacon("/api/ecran/parti?jeton=" + JETON); } catch (e) { }
        if (es) es.close();
      });
      window.addEventListener("pageshow", function (ev) { if (ev.persisted) ouvrir(); });   // retour arrière (cache de page)
    } else {
      // navigateur sans EventSource : on interroge le serveur chaque seconde
      setInterval(function () {
        var x = new XMLHttpRequest();
        x.open("GET", "/api/etat?ecran=" + encodeURIComponent(NOM), true);
        x.onload = function () {
          try { var s = JSON.parse(x.responseText); appliquerEtat(s); changerScene(s.scene); premierInit = false; $("hors-ligne").className = "cache"; } catch (e) { }
        };
        x.onerror = function () { $("hors-ligne").className = ""; };
        x.send();
      }, 1000);
    }
  }
  document.title = "Écran " + NOM;
  taille();
  dessiner();
  if (EDITEUR) { if (window.parent !== window) window.parent.postMessage({ type: "mep-pret" }, location.origin); }
  else if (RELAIS) {
    window.addEventListener("message", function (m) {
      if (m.origin !== location.origin || m.source !== window.parent || !m.data || m.data.type !== "apercu.ev") return;
      try { appliquer(m.data.ev); } catch (e) { }
    });
    window.parent.postMessage({ type: "apercu-pret", nom: NOM }, location.origin);
  }
  else brancher();
})();
